package com.gem.book_mall.dao;

import com.gem.book_mall.pojo.User;

public interface BookAddressDAO {
	boolean addAddress(User user);
}
