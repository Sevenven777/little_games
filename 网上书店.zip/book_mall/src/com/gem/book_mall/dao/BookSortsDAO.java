package com.gem.book_mall.dao;

import java.util.List;

import com.gem.book_mall.pojo.BookSort;

public interface BookSortsDAO {
	List<BookSort> getAllBookSortsById();
}
