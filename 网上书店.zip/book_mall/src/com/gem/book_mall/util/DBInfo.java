package com.gem.book_mall.util;

public interface DBInfo {
	String  DRIVER ="org.gjt.mm.mysql.Driver";
	String URL="jdbc:mysql://localhost:3306/book";
	String USER="root";
	String PWD="root";
	
}
