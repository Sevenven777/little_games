package com.gem.book_mall.biz;

import java.util.List;

import com.gem.book_mall.pojo.BookInfo;

public interface BookSortBiz {
	List<BookInfo> getAllBooks();
}
