/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50536
 Source Host           : localhost:3306
 Source Schema         : book

 Target Server Type    : MySQL
 Target Server Version : 50536
 File Encoding         : 65001

 Date: 31/07/2018 19:09:12
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for b_chart
-- ----------------------------
DROP TABLE IF EXISTS `b_chart`;
CREATE TABLE `b_chart`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `new_price` int(10) NULL DEFAULT NULL,
  `old_price` int(10) NULL DEFAULT NULL,
  `author` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 44 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of b_chart
-- ----------------------------
INSERT INTO `b_chart` VALUES (4, '小王子', 80, 170, '（法）安托万·德·圣', '法国“圣埃克苏佩里基金会”官方认证，正版图片库支持，知名翻译家李继宏良心翻译，张静初、张亮优选版本，每个孩子和长大了的孩子都应该有一本《小王子》，万字深度导读带你真正读懂小王子', 'images/11 (11).jpg');
INSERT INTO `b_chart` VALUES (41, '彩色连环画中国历史', 98, 200, '孟庆江主编 步印童', '五十多位连环画大家联手打造，畅销海外中文世界三十年。万余张彩绘、写实精美插图，连缀成五千年纸上电影。符合时代特征的人物对话，真实还原古人生活场景。带孩子厘清历史脉络，走近并爱上历史（步印童书馆出品）', 'images/11 (6).jpg');
INSERT INTO `b_chart` VALUES (42, '游戏力经典套装', 78, 123, '（美）科恩 著', '美国国家亲子出版奖金奖；以游戏之力，培育合作与勇气；以笑声之力，重建自信，战胜焦虑(新版）', 'images/11 (9).jpg');
INSERT INTO `b_chart` VALUES (43, '图解世界', 100, 200, '[英]亚历克斯·弗里斯', '欧洲教育全新科普阅读，培养孩子核心竞争力，教会孩子探索知识、解决问题的能力。 “2017年英国皇家协会青年图书奖”，300个主题3000+个知识点，给孩子的专属科学通识绘本，塑造逻辑完整的科学认知体系', 'images/11 (10).jpg');

-- ----------------------------
-- Table structure for b_classify
-- ----------------------------
DROP TABLE IF EXISTS `b_classify`;
CREATE TABLE `b_classify`  (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`cid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of b_classify
-- ----------------------------
INSERT INTO `b_classify` VALUES (1, '儿童/育儿');
INSERT INTO `b_classify` VALUES (2, '考试/教辅');
INSERT INTO `b_classify` VALUES (3, '生活/社科');

-- ----------------------------
-- Table structure for b_message
-- ----------------------------
DROP TABLE IF EXISTS `b_message`;
CREATE TABLE `b_message`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `new_price` int(10) NULL DEFAULT NULL,
  `old_price` int(10) NULL DEFAULT NULL,
  `author` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `detail` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `b_id` int(11) NOT NULL COMMENT '书籍分类id',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `b_id`(`b_id`) USING BTREE,
  CONSTRAINT `b_message_ibfk_1` FOREIGN KEY (`b_id`) REFERENCES `b_classify` (`cid`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of b_message
-- ----------------------------
INSERT INTO `b_message` VALUES (1, '图解世界', 100, 200, '[英]亚历克斯·弗里斯', '欧洲教育全新科普阅读，培养孩子核心竞争力，教会孩子探索知识、解决问题的能力。 “2017年英国皇家协会青年图书奖”，300个主题3000+个知识点，给孩子的专属科学通识绘本，塑造逻辑完整的科学认知体系', 3);
INSERT INTO `b_message` VALUES (2, '小王子', 80, 170, '（法）安托万·德·圣', '法国“圣埃克苏佩里基金会”官方认证，正版图片库支持，知名翻译家李继宏良心翻译，张静初、张亮优选版本，每个孩子和长大了的孩子都应该有一本《小王子》，万字深度导读带你真正读懂小王子', 3);
INSERT INTO `b_message` VALUES (3, '老人与海', 123, 234, '（美）厄尼斯特·海', '畅销百万册，梁文道推荐译本，央视朗读者节目推荐，千万级畅销书《追风筝的人》译者李继宏倾心翻译，完整全彩插图本。果麦出品', 2);
INSERT INTO `b_message` VALUES (4, '游戏力经典套装', 78, 123, '（美）科恩 著', '美国国家亲子出版奖金奖；以游戏之力，培育合作与勇气；以笑声之力，重建自信，战胜焦虑(新版）', 2);
INSERT INTO `b_message` VALUES (5, '彩色连环画中国历史', 98, 200, '孟庆江主编 步印童', '五十多位连环画大家联手打造，畅销海外中文世界三十年。万余张彩绘、写实精美插图，连缀成五千年纸上电影。符合时代特征的人物对话，真实还原古人生活场景。带孩子厘清历史脉络，走近并爱上历史（步印童书馆出品）', 1);
INSERT INTO `b_message` VALUES (6, '我要快乐，不必正常', 67, 98, '（英）珍妮特·温特', '《橘子不是唯 一的水果》作者自传。生命不只是一支从子宫飞往坟墓的时间之箭；照自己的意愿活得头破血流，也好过听从别人的安排，虚张声势地过浅薄生活。张悦然、蒋方舟、刘瑜力荐作家,《纽约时报》推荐图书', 1);
INSERT INTO `b_message` VALUES (7, '那个特别的疯子', 54, 78, 'A.F.布雷迪（美国）', '那个特别的疯子(《纽约客》终生作家心理小说，只为洗涤正常人！)', 3);
INSERT INTO `b_message` VALUES (8, '总要习惯一个人', 123, 156, '蕊希 著,博集天卷 出', '治愈千万人、音频总播放量过30亿的人气电台主持人、作家蕊希诚意新作。所有的煎熬和孤独，都成了我走向你的路。世界欠我一个你，是世界欠的，不是你。写给每一个爱过哭过失去过，但依然在用力成长的你.', 3);

-- ----------------------------
-- Table structure for b_user
-- ----------------------------
DROP TABLE IF EXISTS `b_user`;
CREATE TABLE `b_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `pwd` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `phone` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of b_user
-- ----------------------------
INSERT INTO `b_user` VALUES (1, '张三', 'qwe123', '男', '13012345678', '江苏省苏州市');
INSERT INTO `b_user` VALUES (2, 'rose', '123', '女', '110', '江苏省南京市');
INSERT INTO `b_user` VALUES (3, '李四', '1234', 'on', '12345678900', '江苏省南京市');
INSERT INTO `b_user` VALUES (4, '小芳', 'qwer', 'on', '123123123123', '江苏省苏州市工业园区');

-- ----------------------------
-- Table structure for book_img
-- ----------------------------
DROP TABLE IF EXISTS `book_img`;
CREATE TABLE `book_img`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `picture` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `id1` int(25) NOT NULL COMMENT '书籍图片',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `id1`(`id1`) USING BTREE,
  CONSTRAINT `book_img_ibfk_1` FOREIGN KEY (`id1`) REFERENCES `b_message` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of book_img
-- ----------------------------
INSERT INTO `book_img` VALUES (1, 'images/11 (10).jpg', 1);
INSERT INTO `book_img` VALUES (2, 'images/11 (11).jpg', 2);
INSERT INTO `book_img` VALUES (3, 'images/11 (4).jpg', 3);
INSERT INTO `book_img` VALUES (5, 'images/11 (9).jpg', 4);
INSERT INTO `book_img` VALUES (6, 'images/11 (6).jpg', 5);
INSERT INTO `book_img` VALUES (7, 'images/11 (8).jpg', 6);
INSERT INTO `book_img` VALUES (8, 'images/11 (7).jpg', 7);
INSERT INTO `book_img` VALUES (9, 'images/11 (5).jpg', 8);

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `chartid` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `uid`(`uid`) USING BTREE,
  INDEX `chartid`(`chartid`) USING BTREE,
  CONSTRAINT `order_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `b_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `order_ibfk_2` FOREIGN KEY (`chartid`) REFERENCES `b_chart` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for shoping_trolley
-- ----------------------------
DROP TABLE IF EXISTS `shoping_trolley`;
CREATE TABLE `shoping_trolley`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `b-id` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `state` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `u_id`(`u_id`) USING BTREE,
  INDEX `b-id`(`b-id`) USING BTREE,
  CONSTRAINT `shoping_trolley_ibfk_1` FOREIGN KEY (`u_id`) REFERENCES `b_user` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `shoping_trolley_ibfk_2` FOREIGN KEY (`b-id`) REFERENCES `b_message` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
